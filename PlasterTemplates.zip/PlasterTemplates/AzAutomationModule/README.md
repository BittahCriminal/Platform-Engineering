# Plaster Manifest automation template

This Plaster manifest file is used for creating a PowerShell module for Azure Automation account consumption. The manifest provides a set of input parameters to customize the module's metadata and content, allowing you to quickly scaffold a PowerShell module project that meets your specific requirements.

## Prerequisites
Before using this manifest file, you will need to have the following prerequisites installed:

| Requirement | Version | Installation Example |
| --- | --- | --- |
| PowerShell | 5.1 or later | Pre-installed with Windows 10, or can be downloaded from the Microsoft website. |
| Plaster module | 1.3.3 or later | `Install-Module Plaster -RequiredVersion 1.3.3` |
| Pester module | 5.3.1 or later | `Install-Module Pester -RequiredVersion 5.3.1` |
| PSScriptAnalyzer | 1.21.0 or later | `Install-Module PSScriptAnalyzer -RequiredVersion 1.21.0` |
| PsDeploy | 1.0.5 or later | `Install-Module PsDeploy -RequiredVersion 1.0.5` |
| PlatyPS | 0.14.2 or later | `Install-Module PlatyPS -RequiredVersion 0.14.2` |


## Usage

1.  Clone or download this Plaster manifest file to your local machine.
2.  Open a PowerShell console and navigate to the directory where the Plaster manifest file is saved.
3.  Run the following command to execute the Plaster manifest file:
    
    ```shell 
    Invoke-Plaster -TemplatePath .\AzureAutomationManifest.xml
    ```
    
4.  Follow the prompts to provide the input parameters for the module. You can customize the module's name, version, description, author, tags, package feed name, project URL, and editor choice. (See below for parameter definitions and example)
5.  Once the input parameters have been provided, the PowerShell module project will be created in a new directory with the specified module name.
6.  You can then customize the module's content by modifying the included files and adding your own PowerShell scripts.

### Parameters of the Manifest File

The Plaster manifest file has several parameters that can be customized to fit the needs of your project. These parameters can be specified at runtime when invoking the Plaster command to create a new project from the template.

Here are some of the parameters that can be customized:

- `ModuleName`: This is the name of your PowerShell module. It will be used as the name of the module directory and as the basis for the module's manifest file.
- `Version`: This is the version number of your PowerShell module.
- `Description`: This is a brief summary of the module's intended use.
- `Author`: This is the team responsible for the maintenance of the module.
- `Tags`: These are comma-separated metadata relevant to the module, used to make it more searchable in an artifact manager.
- `PackageFeedName`: This is the name of the artifact feed to publish the module to.
- `ProjectURL`: This is the git project URL of the repository.
- `Editor`: This is the editor of your choice for opening the project files.

These parameters can be specified when invoking the Plaster command, like this:

```shell
Invoke-Plaster -TemplatePath <path\to\template> -DestinationPath <path\to\destination> -ModuleVersion <version> -ModuleName <name> -Description <description> -Author <author> -Tags <tags> -PackageFeedName <feedname> -ProjectURL <url> -Editor <editor>
```
