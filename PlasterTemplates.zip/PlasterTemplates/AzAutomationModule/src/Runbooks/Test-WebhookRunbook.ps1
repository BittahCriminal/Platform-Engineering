<#
    .Synopsis
        A brief statement about the runbook
    .Description
        A more verbose statement about the runbook
    .Parameter WebhookData
        A pscustomobject or a json body
    .Notes
        List relevant notes on the behavior of the runbook 
    .Example
        Provide examples on running the runbook
#>

param
(

    [Parameter(Mandatory = $true)]
    [object]$WebhookData

)

Write-Verbose "Any inline comments you wish to add"
$result = [PSCustomObject]@{} #the output object, what you want the customer to see or what you want to pass through to another program/script/whatever

$results | Add-Member -MemberType NoteProperty -Name WebhookData -Value $WebhookData

Write-Output $result