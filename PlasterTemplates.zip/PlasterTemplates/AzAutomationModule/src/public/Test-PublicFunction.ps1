function Test-PublicFunction {
    <#
        .Synopsis
            A brief statement about the Public CMDLet
        .Description
            A more verbose statement about the Public CMDLet
        .Parameter WebhookData
            A pscustomobject or a json body
        .Notes
            List relevant notes on the behavior of the Public CMDLet
        .Example
            Provide examples on running the Public CMDLet
    #>
    param (
        [Parameter(Mandatory = $false)]
        [string]$someFile = 'c:\someFile.txt'
    )


    try {
        $params = @{
            itemType    = 'file'
            Path        = $someFile
            ErrorAction = 'Stop'
            Force       = $true
            Verbose     = $true
        }
        $newFile = New-Item @params
    }
    catch {
        throw $error[0].Exception
        break
    }

    $newFile
}