#Functions in the module scope are defined here. Exported "public" functions are in the module manifest file.
$moduleRoot = Split-Path -Path $MyInvocation.MyCommand.Path

"$moduleRoot\public\*.ps1" |
Resolve-Path | ForEach-Object { . $_.ProviderPath }

"$moduleRoot\private\*.ps1" |
Resolve-Path | ForEach-Object { . $_.ProviderPath }