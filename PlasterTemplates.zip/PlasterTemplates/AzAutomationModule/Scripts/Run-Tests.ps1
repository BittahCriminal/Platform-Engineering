<#
    This is a simple script file that is expected to be executed by an ADO agent runner.
#>
$moduleRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
Set-Location $moduleRoot -Verbose:$VerbosePreference
Invoke-Tests -OutputFile $env:outputFile -CoverageFile $env:CoverageFile -Verbose:$VerbosePreference