<#
    .Synopsis
        Updates the PlatformTools module manifest based on changes made to the module, and unput from the user implementing the change
    .Description
        The updates to the module manifest updates the following:
            1. The Version of the powershell module
                a. If MajorUpgrade is toggled, minor and build is reset to zero
                b. if a new public function is added, each one added increase the minor version
                c. if none of the above, it is considered a behavior update or a bug fux and adds 1 to the build number
            2. Generates a new GUID for the module
            3. Update the release notes based input.
    .Parameter ReleaseNotesBlock
        This will automatically concatinate the release notes in the psd1 file for the module. do not add module version in the notes as this is already calculated and added as a prefix
    .Parameter majorUpgrade
        If toggled, this automatically increases the Major versioning by 1. and the Minor and build versions are reset to 0
    .Example
        modules\PlatformTools\AutomatedModuleManifest.ps1 -MajorRelease -ReleaseNotesBlock "A note about what you added, or changed"
    .Notes
        created for use of the platform team, use/mod/delete as needed.
        This assumes a version type with three digits. This is important if you want to utilize the azure artifacts private repo feature. It does not support 4 for some reason.

#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]
    $ReleaseNotesBlock,

    [Parameter(Mandatory = $false)]
    [string]
    $ModuleManifestPath = ((Resolve-Path "$PWD\src").Path),

    [Parameter(Mandatory = $false)]
    [string]
    $ModuleName = (Get-ChildItem $ModuleManifestPath\*.psd1 | Split-Path -Leaf | ForEach-Object { [System.IO.Path]::GetFileNameWithoutExtension($_) }),

    [Parameter(Mandatory = $false)]
    [switch]
    $MajorUpgrade,

    [Parameter(Mandatory = $false)]
    [switch]
    $MinorUpgrade
)

if (!$ModuleManifestPath -or !(Test-Path $ModuleManifestPath)) {
    Throw "Invalid manifest path '$ModuleManifestPath'!`nScript must be run from root of module folder."
}

Write-Verbose "Getting module manifest data"
Remove-Module -Name $ModuleName -ErrorAction SilentlyContinue

# this section is highly suspect and only used to workaround the mess left behind
# be PowerShell's Test-ModuleManifest failing if you don't have a module installed
# in one of the PSModulePath folders
# https://stackoverflow.com/questions/46216038/how-do-i-define-requiredmodules-in-a-powershell-module-manifest-psd1
$moduleData = Import-PowerShellDataFile -Path "$ModuleManifestPath\$ModuleName.psd1"
if ($moduleData.RequiredModules) {
    $currentUserModulePath = $env:PSModulePath.Split(';')[0]
    foreach ($module in $moduleData.RequiredModules) {
        if (!(Get-Module $module)) {
            Throw "Required module '$module' is not loaded!  Load then run script again."
        }

        $moduleInfo = Get-Module -Name $module
        $newPath = "$currentUserModulePath/$($moduleInfo.Name)/$($moduleInfo.Version)"
        if (!(Test-Path $newPath)) {
            New-Item -Path $newPath -ItemType Directory -Force | Out-Null
            $currentPath = Split-Path $moduleInfo.Path -Parent
            Copy-Item -Path "$currentPath/*" -Destination $newPath -Recurse
        }
    }
}
# hackery ends here

Import-Module -Name "$ModuleManifestPath\$ModuleName.psd1"
$manifestData = Get-Module $ModuleName

Write-Verbose "Getting Public Functions and generating list for functions to export"
$publicFunctions = Get-ChildItem -Path ("$($manifestData.ModuleBase)\public")
$functionsToExport = @()
foreach ($func in $publicFunctions) {
    $functionsToExport += $func.Name.replace('.ps1', '')
}

Write-Verbose "Determining module version"
$major = $manifestData.Version.Major
$minor = $manifestData.Version.Minor
$build = $manifestData.Version.Build

if ($MajorUpgrade) {
    $major = ($manifestData.Version.Major + 1)
    $minor = 0
    $build = 0
}
else {
    $major = $manifestData.Version.Major
    if ($MinorUpgrade) {
        $minor = $manifestData.Version.Minor + 1
        $build = 0
    }
    else {
        $minor = $manifestData.Version.Minor
    }

    $build = $manifestData.Version.Build + 1
}

$versionStr = "$major.$minor.$build"
$moduleVersion = [System.Version]$versionStr
$releaseNotes = $manifestData.ReleaseNotes + "`n`t`t`t-v$versionStr - $ReleaseNotesBlock"
$guid = [Guid]::NewGuid().Guid

Write-Verbose "Updating Module Manifest"
Update-ModuleManifest -Path "$ModuleManifestPath\$ModuleName.psd1" -Guid $guid -FunctionsToExport $functionsToExport -ModuleVersion $moduleVersion -ReleaseNotes $releaseNotes

Write-Verbose "Updating Nuspec Manifest"
[xml]$nuspec = Get-Content -Path "$ModuleManifestPath/$ModuleName.nuspec" -Raw
$metadata = $nuspec.package.metadata
$metadata.version = $versionStr
$metadata.releaseNotes = $ReleaseNotesBlock
$nuspec.Save("$ModuleManifestPath/$ModuleName.nuspec")
