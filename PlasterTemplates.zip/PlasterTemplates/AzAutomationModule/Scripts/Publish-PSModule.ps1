$ErrorActionPreference = 'Stop'
Install-PackageProvider -Name Nuget -Scope CurrentUser -force -Confirm:$false -Verbose:$VerbosePreference
$moduleRoot = Split-Path -Path $MyInvocation.MyCommand.Path
Publish-Module -Path $moduleRoot -Force -Verbose:$VerbosePreference -Repository <%=$PLASTER_PARAM_PACKAGEFEEDNAME%>