
function Invoke-Tests {
    <#
    .SYNOPSIS
        Short description
    .DESCRIPTION
        Long description
    .EXAMPLE
        PS C:\> <example usage>
        Explanation of what the example does
    .INPUTS
        .PARAMETER outPutFile

        .PARAMETER codeCoverageFile

    .OUTPUTS
        Output (if any)
    .NOTES
        General notes
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string]$outPutFile,

        [Parameter(Mandatory = $true)]
        [string]$codeCoverageFile
    )



    Write-Verbose -Message "Checking the installation of Nuget Package Provider." -Verbose:$VerbosePreference -Debug:$DebugPreference
    if (-not (Get-PackageProvider -Name NuGet)) {
        try {
            Write-Verbose -Message "Attempting install"
            $paramSplat = @{
                Name = "Nuget" 
                Scope = "CurrentUser" 
                Force = [switch]$true
                Confirm = $false 
                ErrorAction = "Stop" 
                ErrorVariable = 'NugetError' 
                Verbose = $VerbosePreference
                Debug = $DebugPreference
            }
            Install-PackageProvider @paramSplat 
        }
        catch {
            Write-Error "Failed to install the Nuget Package provider. Error: < $(NugetError.Message) >"
            break
        }
    }
    
    $reqModules = @(
        @{
            Name = 'PSSCriptAnalyzer'
            MinimumVersion = 1.20.0
        },
        @{
            Name = 'Pester'
            MinimumVersion = 5.3.1
        }
    )
    Write-Verbose "Checking for required modules."
    $reqModules | ForEach-Object {
        if (-not [bool]($_ | Get-InstalledModule)) {
            try{
                Write-Verbose "Installing module $($_.Name)"
                $paramSplat = @{
                    Scope = "CurrentUser" 
                    Force = [switch]$true 
                    Confirm = $false
                    ErrorAction = "Stop"
                    ErrorVariable = "ModuleInstallError"
                    Verbose = $VerbosePreference
                    Debug = $DebugPreference
                }
                $_ | Install-Module @paramSplat
            }
            catch{
                Write-Error "Unable to install module $($_.Name). Error: < $($ModuleInstallError.Message) >"
            }
        }
    }
    Write-Verbose "Running Pester Tests"
    if($PSCmdlet.ShouldProcess($outputFile, "Invokeing tests will create an outputFIle")) {
        try{
            $paramSplat = @{
                OutputFile = $outPutFile 
                OutputFormat = "NUnitXml" 
                CodeCoverage = @{path = "*"} 
                CodeCoverageOutputFile = $codeCoverageFile 
                ErrorAction = "Stop" 
                Verbose=$VerbosePreference 
                ErrorVariable="PesterTestError"
            }

            Invoke-Pester @paramSplat
        }
        catch{
            Write-Error "Unable to invoke tests. Error: < $($PesterTestError.Message) >"
        }
    }
}