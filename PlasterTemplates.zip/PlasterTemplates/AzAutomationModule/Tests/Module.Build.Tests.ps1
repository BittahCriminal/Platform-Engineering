$scriptRoot = $PSScriptRoot

Describe <%=$PLASTER_PARAM_ModuleName%> {

    BeforeAll {
        # set working path
        $pathtest = Split-Path $scriptRoot -Parent
        Set-Location $pathtest

        # get public functions to ensure that they're being exported correctly in meta context
        $publicfunctions = @()
        $functions = Get-ChildItem "./src/public"
        $functions.Name | ForEach-Object {
            $split = $_.split('.')
            $publicfunctions += $split[0]
        }
    }

    AfterAll {
        if (Get-Module -Name <%=$PLASTER_PARAM_ModuleName%>) {
            Remove-Module -Name <%=$PLASTER_PARAM_ModuleName%>
        }

    }

    # meta tests for module
    Context meta {

        It "Should Import" {
            { Import-Module -Name .\src\<%=$PLASTER_PARAM_ModuleName%>.psd1 -ErrorAction Stop } | Should -Not -Throw
        }

        $module = Get-Module <%=$PLASTER_PARAM_ModuleName%>
        $publicfunctions | ForEach-Object {
            It "Should export function < $($_) > in public folder" {
                $module.ExportedCommands.Keys -contains $_  | Should -Be $true
            }
        }
    }

}
