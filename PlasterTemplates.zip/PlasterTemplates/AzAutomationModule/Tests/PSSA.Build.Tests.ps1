$scriptRoot = $PSScriptRoot

Describe 'PS Script Analyzer' {
    BeforeAll {
        # set working path
        $pathtest = Split-Path $scriptRoot -Parent
        Set-Location $pathtest

        if (!(Get-Module PSScriptAnalyzer)) {
            Import-Module PSScriptAnalyzer
        }
    }

    Context 'Custom Rules' {
        $customRules = Import-LocalizedData -BaseDirectory "../../analyzers" -FileName 'CustomPSSARules.psd1'
        $scriptAnalyzerRules = Get-ScriptAnalyzerRule -Name $customRules.IncludeRules
        $analysis = Invoke-ScriptAnalyzer -Recurse -Path "./src" -IncludeRule $customRules.IncludeRules -ExcludeRule $customRules.ExcludeRules -Severity $customRules.Severity

        forEach ($rule in $scriptAnalyzerRules) {
            It "$rule" {
                If ($analysis.RuleName -contains $rule) {
                    $analysis | Where-Object { $_.RuleName -EQ $rule } -OutVariable failures | Out-Default
                    $failures.Count | Should -Be 0
                }
            }
        }
    }
}

