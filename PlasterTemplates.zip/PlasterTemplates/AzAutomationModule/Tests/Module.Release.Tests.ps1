[CmdletBinding()]
param (
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$ArtifactFeed = "InfrastructureServices",

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$RepositoryName = "AzureArtifactsRepo"
)

$scriptRoot = $PSScriptRoot

Describe '<%=$PLASTER_PARAM_ModuleName%>' -Tag 'Release' {

    BeforeAll {
        $pathtest = Split-Path $scriptRoot -Parent
        Push-Location $pathtest

        # Get data from module manifest we deployed to ADOS to compare to what is installed from repository
        Import-LocalizedData -BaseDirectory "./src" -FileName '<%=$PLASTER_PARAM_ModuleName%>.psd1' -BindingVariable manifestData

        # Check for already installed module and if so, uninstall
        Write-Host "Checking if <%=$PLASTER_PARAM_ModuleName%> module is already installed and if so uninstalling for new install test"
        $result = Get-Module -ListAvailable <%=$PLASTER_PARAM_ModuleName%>
        if ($result) {
            Uninstall-Module -Name <%=$PLASTER_PARAM_ModuleName%> -Force
        }
    }

    AfterAll {
        # Uninstall module
        Write-Host "Testing complete, uninstalling <%=$PLASTER_PARAM_ModuleName%> module"
        $result = Get-Module -ListAvailable <%=$PLASTER_PARAM_ModuleName%>
        if ($result) {
            Uninstall-Module -Name <%=$PLASTER_PARAM_ModuleName%> -Force
        }

        Unregister-PSRepository -Name $RepositoryName -ErrorAction SilentlyContinue
        Unregister-PackageSource -Name $RepositoryName -ErrorAction SilentlyContinue

        Pop-Location
    }

    It 'Repository should be registered' {
        # Check if package provider is already registered and if not, register
        if (!(Get-PackageProvider -Name NuGet)) {
            Install-PackageProvider -Name NuGet -Force -Scope CurrentUser
        }

        # Check if repository is already registered and if not, register
        $repos = Get-PSRepository
        if ($repos.name -notcontains $RepositoryName) {
            Write-Host "$RepositoryName repository is not currently registered on the machine, proceeeding to register"
            Register-PackageSource -Name $RepositoryName `
                                   -Location "https://pkgs.dev.azure.com/DevOps-Repo/Scrum/_packaging/$ArtifactFeed/nuget/v2" `
                                   -ProviderName NuGet `
                                   -SkipValidate

            Register-PSRepository -Name $RepositoryName `
                                  -SourceLocation "https://pkgs.dev.azure.com/DevOps-Repo/Scrum/_packaging/$ArtifactFeed/nuget/v2" `
                                  -PublishLocation "https://pkgs.dev.azure.com/DevOps-Repo/Scrum/_packaging/$ArtifactFeed/nuget/v2" `
                                  -InstallationPolicy Trusted

            $repos = Get-PSRepository
            $repos.name -contains $RepositoryName | Should -Be True
        }
        else {
            Write-Host "$RepositoryName repository is already registered on the machine"
            $repos.name -contains $RepositoryName | Should -Be True
        }
    }

    It 'Module should install' {
        Install-Module -Name <%=$PLASTER_PARAM_ModuleName%> -Repository $RepositoryName -Scope CurrentUser -AllowClobber
        $module = Get-Module -ListAvailable <%=$PLASTER_PARAM_ModuleName%>
        $module | Should -Not -Be $null
    }

    It 'Module should be latest version' {
        Write-Host "Current version of module being published is $($manifestData.ModuleVersion), testing that is the installed version..."
        $module = Get-Module -ListAvailable <%=$PLASTER_PARAM_ModuleName%>
        $module.version | Should -Be $manifestData.ModuleVersion
    }

}
